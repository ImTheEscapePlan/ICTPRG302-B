.foo.bar
