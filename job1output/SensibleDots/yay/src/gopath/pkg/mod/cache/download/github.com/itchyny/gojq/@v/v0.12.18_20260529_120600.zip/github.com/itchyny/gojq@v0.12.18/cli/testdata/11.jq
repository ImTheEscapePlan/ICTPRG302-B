.foo,

[],

bar ]
