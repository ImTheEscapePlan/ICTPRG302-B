.foo | {
  foo,
  bar, []
}
