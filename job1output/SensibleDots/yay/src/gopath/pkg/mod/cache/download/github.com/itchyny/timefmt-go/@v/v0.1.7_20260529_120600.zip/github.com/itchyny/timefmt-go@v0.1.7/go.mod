module github.com/itchyny/timefmt-go

go 1.24
